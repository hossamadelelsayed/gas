/**
 * Created by a4p2 on 8/28/2017.
 */
export class User {
  public static readonly Customer: string = 'customer';
  public static readonly Distributor: string = 'distributor';
}
