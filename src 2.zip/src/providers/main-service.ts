import {NativeStorage} from '@ionic-native/native-storage';

export class MainService{
    public static lang :string ='ar';
}