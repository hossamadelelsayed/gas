export class MainService{
    public static lang :string ='ar';
}