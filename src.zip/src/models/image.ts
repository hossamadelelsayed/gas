export class Image{
  public static readonly Profile:number=1;
  public static readonly Front:number=2;
  public static readonly Back:number=3;

    constructor(public Type:number,public Image:string,public ImgSRC:string){

    }
      
  }

    